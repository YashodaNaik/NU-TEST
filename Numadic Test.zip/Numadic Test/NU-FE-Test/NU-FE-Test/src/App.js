import React, { useState, useEffect } from "react";
import clsx from 'clsx';
import { makeStyles } from "@material-ui/core/styles";
import Grid from "@material-ui/core/Grid";
import Table from "@material-ui/core/Table";
import TableBody from "@material-ui/core/TableBody";
import TableCell from "@material-ui/core/TableCell";
import TableContainer from "@material-ui/core/TableContainer";
import TableHead from "@material-ui/core/TableHead";
import TableRow from "@material-ui/core/TableRow";
import Paper from "@material-ui/core/Paper";
import TablePagination from '@material-ui/core/TablePagination';
import axios from "axios";
import SwipeableDrawer from '@material-ui/core/SwipeableDrawer';
import Button from '@material-ui/core/Button';
import List from '@material-ui/core/List';
import Divider from '@material-ui/core/Divider';
import ListItem from '@material-ui/core/ListItem';

import ListItemText from '@material-ui/core/ListItemText';


import "./App.css";

const countriesURL = "https://restcountries.eu/rest/v2/all";

const useStyles = makeStyles ((theme) => ({
  table: {
    minWidth: 650,
  },
  TableContainer: {
    borderRadius :15,
    margin : '20px 20px',
    maxWidth : 1225,

   
  },
  TableHeaderCell : {
    fontWeight: 'bold',
    backgroundColor: theme.palette.primary.dark,
    color: theme.palette.getContrastText(theme.palette.primary.light),
  },

  
}));


function DenseTable() {
  const [countriesData, setCountriesData] = useState([]);
 
  const classes = useStyles();
  const [state, setState] = React.useState({
    right: false,
  });
  const toggleDrawer = (anchor, open) => (event) => {
    if (event && event.type === 'keydown' && (event.key === 'Tab' || event.key === 'Shift')) {
      return;
    }

    setState({ ...state, [anchor]: open });
  };


  const getCountriesWithAxios = async () => {
    const response = await axios.get(countriesURL);
    setCountriesData(response.data);
    
  };
  const [page, setPage] = React.useState(2);
  const [rowsPerPage, setRowsPerPage] = React.useState(5);

  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(0);
  };


  useEffect(() => {
    getCountriesWithAxios();
  }, []);

  const list = (anchor) => (
    <div
      className={clsx(classes.list, {
        [classes.fullList]: anchor === 'top' || anchor === 'bottom',
      })}
      role="presentation"
      onClick={toggleDrawer(anchor, false)}
      onKeyDown={toggleDrawer(anchor, false)}
    >
      <List>
        {['Inbox', 'Starred', 'Send email', 'Drafts'].map((text, index) => (
          <ListItem button key={text}>
    
            <ListItemText primary={text} />
          </ListItem>
        ))}
      </List>
      <Divider />
      <List>
        {['All mail', 'Trash', 'Spam'].map((text, index) => (
          <ListItem button key={text}>
            <ListItemText primary={text} />
          </ListItem>
        ))}
      </List>
    </div>
  );
  return (
    <div>
      {countriesData.map((anchor) => (
        <React.Fragment key={anchor}>
          <Button onClick={toggleDrawer(anchor, true)}>{anchor}</Button>
          <SwipeableDrawer
            anchor={anchor}
            open={state[anchor]}
            onClose={toggleDrawer(anchor, false)}
            onOpen={toggleDrawer(anchor, true)}
          >
            {list(anchor)}
          </SwipeableDrawer>
        </React.Fragment>
      ))}
    </div>
  );
      }

render() {
   return (
    <>
      <Grid container>
        <Grid item xs={12}>
          <TableContainer component={Paper} className={classes.TableContainer}>
            <Table className={classes.table} aria-label="sticky table">
              <TableHead >
                <TableRow>
                  <TableCell className={classes.TableHeaderCell}>
                    <strong>Name</strong>
                  </TableCell>
                  <TableCell className={classes.TableHeaderCell} align="right">
                    <strong>Flag</strong>
                  </TableCell>
                  <TableCell className={classes.TableHeaderCell} align="right">
                    <strong>Capital</strong>
                  </TableCell>
                  <TableCell className={classes.TableHeaderCell} align="right">
                    <strong>Population</strong>
                  </TableCell>
                  <TableCell className={classes.TableHeaderCell} align="right">
                    <strong>Region</strong>
                  </TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {countriesData.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage).map((country) => (
                  <TableRow key={country.callingCodes+country.name}>{/*edit*/} 
                    <TableCell component="th" scope="row">
                      {country.name}{/*edit*/} 
                    </TableCell>
                    <TableCell align="right">
                      <img src={country.flag} alt="" width="45px"/>{/*edit*/} 
                    </TableCell>
                    <TableCell align="right">{country.capital}</TableCell>{/*edit*/}
                    <TableCell align="right">{country.population}</TableCell>
                    <TableCell align="right">{country.region}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
          <TablePagination
          rowsPerPageOptions={[5, 10, 15]}
      component="div"
      count={countriesData.length}
      page={page}
      onPageChange={handleChangePage}
      rowsPerPage={rowsPerPage}
      onRowsPerPageChange={handleChangeRowsPerPage}
    />
        </Grid>
      </Grid>
    </>
    
  );
                
}


export default DenseTable;
